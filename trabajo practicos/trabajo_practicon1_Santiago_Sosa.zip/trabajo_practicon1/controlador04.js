
/*
Ejercicio Nro. 04: Estructuras Condicionales (if/else)
Ingrese un número y determine si es positivo o negativo usando una estructura condicional if/else y
también resuelva el mismo problema utilizando un operador ternario
*/

{

    let numero1 = 0;
   
    numero1 = Number(prompt(`Ingrese un numero:`))


    if (numero1 > 0 )
    {
        console.log(`El numero ingresado positivo`)
    }
    else
    {
        console.log(`El numero ingresado es negativo`)
    }

    
}